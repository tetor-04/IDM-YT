================================================================
  IDM Video Downloader - Portable Windows Edition
================================================================

Version: 1.0.0
License: Valid until December 31, 2025
Build Date: Tue 10/14/2025 20:14:34.57

================================================================
  QUICK START
================================================================

1. Double-click: IDM_Video_Downloader.exe
2. Paste a YouTube video URL
3. Click "Fetch Info" to load video details
4. Choose download type:
   - Video: Select quality (4K, 1080p, 720p, etc.)
   - Audio: Select quality (320/192/128/96 kbps)
5. Select download location
6. Click "Download"

================================================================
  FEATURES
================================================================

VIDEO DOWNLOADS:
  - Multiple qualities: 144p to 4K
  - Formats: MP4, WebM, and more
  - Real-time progress tracking
  - Works without FFmpeg

AUDIO DOWNLOADS:
  - With FFmpeg: MP3 format (320/192/128/96 kbps)
  - Without FFmpeg: Original format (webm/m4a)
  - High quality audio extraction

INTERFACE:
  - User-friendly GUI
  - Separate Video/Audio modes
  - Real-time progress bar
  - Detailed logging
  - Custom download path

================================================================
  FFMPEG (Optional - for MP3 conversion)
================================================================

To convert audio to MP3, install FFmpeg:

METHOD 1: Use the included script
  - Run: install_ffmpeg.bat
  - Follow the menu options

METHOD 2: Chocolatey
  choco install ffmpeg

METHOD 3: Winget
  winget install ffmpeg

METHOD 4: Manual
  1. Download: https://ffmpeg.org/download.html
  2. Extract to C:\ffmpeg
  3. Add C:\ffmpeg\bin to system PATH
  4. Restart computer

NOTE: Audio downloads work WITHOUT FFmpeg
      (saves in original format like webm/m4a)

================================================================
  SUPPORTED SITES
================================================================

YouTube and 1000+ other video sites including:
  - Vimeo, Dailymotion, Facebook, Instagram
  - TikTok, Twitter, Twitch
  - And many more...

================================================================
  TROUBLESHOOTING
================================================================

Problem: Can't fetch video info
Solution: - Check your internet connection
         - URL may contain playlist params (app auto-removes)
         - Try updating yt-dlp (in non-portable version)

Problem: Audio download fails
Solution: - Install FFmpeg for MP3 conversion
         - Or download in original format (works without FFmpeg)

Problem: Download is slow
Solution: - Depends on your internet speed
         - Server speed varies by site

================================================================
  SYSTEM REQUIREMENTS
================================================================

- Windows 7, 8, 10, or 11
- Internet connection
- 50MB free disk space (for app)
- FFmpeg (optional, for MP3 conversion)

================================================================
  LICENSE INFORMATION
================================================================

This is a TRIAL version valid until: December 31, 2025
After this date, the application will stop working.

================================================================
  PORTABLE FEATURES
================================================================

- No installation required
- Run from any location
- Run from USB drive
- No registry modifications
- Self-contained executable
- Copy and share easily

For more details, see README_FULL.md

Enjoy downloading! )

